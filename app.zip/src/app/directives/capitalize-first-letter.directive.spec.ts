import { CapitalizeFirstLetterDirective } from './capitalize-first-letter.directive';

describe('CapitalizeFirstLetterDirective', () => {
  it('should create an instance', () => {
    const directive = new CapitalizeFirstLetterDirective();
    expect(directive).toBeTruthy();
  });
});
