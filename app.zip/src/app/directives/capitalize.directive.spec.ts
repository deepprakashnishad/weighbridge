import { CapitalizeDirective } from './capitalize.directive';

describe('CapitalizeDirective', () => {
  it('should create an instance', () => {
    const directive = new CapitalizeDirective();
    expect(directive).toBeTruthy();
  });
});
