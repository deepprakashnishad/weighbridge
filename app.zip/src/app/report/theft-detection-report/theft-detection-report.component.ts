import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theft-detection-report',
  templateUrl: './theft-detection-report.component.html',
  styleUrls: ['./theft-detection-report.component.css']
})
export class TheftDetectionReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
