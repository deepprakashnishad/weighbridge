import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-reports',
  templateUrl: './custom-reports.component.html',
  styleUrls: ['./custom-reports.component.css']
})
export class CustomReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
