import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zero-check-report',
  templateUrl: './zero-check-report.component.html',
  styleUrls: ['./zero-check-report.component.css']
})
export class ZeroCheckReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
