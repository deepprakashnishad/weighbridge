import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-log',
  templateUrl: './notification-log.component.html',
  styleUrls: ['./notification-log.component.css']
})
export class NotificationLogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
