import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-collection-report',
  templateUrl: './daily-collection-report.component.html',
  styleUrls: ['./daily-collection-report.component.css']
})
export class DailyCollectionReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
