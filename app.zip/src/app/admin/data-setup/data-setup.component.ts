import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-setup',
  templateUrl: './data-setup.component.html',
  styleUrls: ['./data-setup.component.css']
})
export class DataSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
