import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-edit-additional-field',
  templateUrl: './create-edit-additional-field.component.html',
  styleUrls: ['./create-edit-additional-field.component.css']
})
export class CreateEditAdditionalFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
