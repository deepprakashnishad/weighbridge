export class AdditionalField{
    displayName: string;
    inOutMode: string;
    dataEntryMode: string;
    dataType: string;
    entryOn: string;
    formula: string;
    isMandatory: boolean;
}