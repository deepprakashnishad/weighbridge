export class Permission {
	permission: string;
	id: string;
	description:"string";
	createdAt: number;
	updatedAt: number;
}

