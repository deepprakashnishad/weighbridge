import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weighbridge-setup',
  templateUrl: './weighbridge-setup.component.html',
  styleUrls: ['./weighbridge-setup.component.css']
})
export class WeighbridgeSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
