export class Tag{
    tagType: string;
    value: string;
    comment: string;
    createdBy: number;
}
