export const environment = {
  production: true,
  licenseurl: "https://aesm-license-manager.herokuapp.com",
  appName: "accubridge",
  appDisplayName: "Accubridge",
  firstAutoRefresh: true,
  version: "1.0.0"
};


