var soap = require('strong-soap').soap;
const { app, ipcMain } = require('electron');
const db = require('./db-service.js');

var options = {
  wsdl_headers: {
    'Authorization': 'Basic ' + new Buffer('bflpidev' + ':' + 'pi1234').toString('base64'),
  }
};

ipcMain.handle("sendDataToSAP", async (event, args) => {
  try {
    //dummyDriver(args[0]);
    sendToSAP(args[0]);
  } catch (err) {
    log.error(err);
    return { error: err.message };
  }
});

//function dummyDriver(data) {
//  for (var i = 0; i < data.length; i++) {
//    data[i].SYNC_FLAG = 1;
//    updateSyncFlag(data[i]);
//  }
//}

function sendToSAP(data) {
  //Data in Request Body
  if (data.length) {
    
    //wsdl service
    var url = "http://bfpdv1.kalyanicorp.com:50000/dir/wsdl?p=ic/c50e2242ef723dee8dfebc7dbcedb0f6";
    
    //wsdl service data input format
    var RequestData = {
      MT_WEIGHBRIDGE_WEIGHT_DATA_REQ: {
        WEIGHBRIDGE_TAB: {
          WEIGHBRIDGE_DATA: data
        }
      }
    }
    //Create SOAP client
    soap.createClient(url, options, function (err, client) {
      if (err) {
        log.error(err);
        return err
      }

      //Set Authorisation
      client.setSecurity(new soap.BasicAuthSecurity('bflpidev', 'pi1234'));

      //wsdl Service call 
      client.SI_WEIGHBRIDGE_WEIGHT_DATAService.HTTP_Port.SI_WEIGHBRIDGE_WEIGHT_DATA(RequestData, function (err, response, envelope) {
        if (err) {
          console.log(err);
          return err;
        } else {
          if (response['WEIGHBRIDGE_TAB']['WEIGHBRIDGE_DATA']) {
            var itemsResponse = [];
            itemsResponse = response['WEIGHBRIDGE_TAB']['WEIGHBRIDGE_DATA'];
            itemsResponse.forEach(element => {
              if (element.SYNC_FLAG == 1) {
                updateSyncFlag(element);
              }
            });
          }
        }
      });
    });
  }
}

function updateSyncFlag(data){
  var stmt = `UPDATE weighment SET syncFlag=1 WHERE rstNo=${data['WEIGHMENT_RST_NO']}`;
  console.log(stmt);
  db.stmtExecutor("UPDATE", stmt);
}
